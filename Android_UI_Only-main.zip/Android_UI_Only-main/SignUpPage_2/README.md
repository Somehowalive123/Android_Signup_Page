# MySignupApp

Simple Registration page or SignUp page Design for android app

Full Video Tutorial is available in Youtube Link : https://youtu.be/0QqAkopW31M

![REGISTER](https://user-images.githubusercontent.com/68380115/126687880-e4034961-9847-4832-88e5-69f40848f0bd.PNG)
