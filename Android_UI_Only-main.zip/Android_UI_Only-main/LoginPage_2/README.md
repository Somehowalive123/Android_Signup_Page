# My Login Page 

Simple Login Design for android app

Full Video Tutorial is available in Youtube Link : https://youtu.be/04bzIg3Xuvg

<img width="1512" alt="Screenshot 2023-08-05 at 10 53 21" src="https://github.com/easy-tuto/MyLogin2/assets/68380115/75d5f9fd-8437-4b7f-b37d-c52640d9fceb">
